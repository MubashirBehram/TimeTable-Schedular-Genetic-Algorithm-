import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URI;
 
public class ContactLink extends JLabel {
 
    // Put your link here. Examples:
    //   a website:  "https://example.com/contact"
    //   an email:   "mailto:you@example.com"
    // While this is empty, clicking only shows a "not set yet" message.
    private static final String LINK = "";
 
    public ContactLink() {
        super("<html><u>Contact us</u></html>", SwingConstants.CENTER);
        setForeground(new Color(0, 102, 204));
        setCursor(new Cursor(Cursor.HAND_CURSOR));
 
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                openLink();
            }
        });
    }
 
    private void openLink() {
        String link = LINK.trim();
 
        if (link.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No contact link has been set yet.");
            return;
        }
 
        if (!Desktop.isDesktopSupported()) {
            JOptionPane.showMessageDialog(this, "Links cannot be opened on this system.");
            return;
        }
 
        try {
            Desktop desktop = Desktop.getDesktop();
            URI uri = new URI(link);
 
            if (link.toLowerCase().startsWith("mailto:")
                    && desktop.isSupported(Desktop.Action.MAIL)) {
                desktop.mail(uri);
            } else if (desktop.isSupported(Desktop.Action.BROWSE)) {
                desktop.browse(uri);
            } else {
                JOptionPane.showMessageDialog(this, "Links cannot be opened on this system.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Could not open the link: " + link);
        }
    }
}
