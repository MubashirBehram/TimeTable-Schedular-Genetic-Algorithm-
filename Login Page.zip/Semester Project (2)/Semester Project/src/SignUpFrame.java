import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
public class SignUpFrame implements ActionListener {
 
    private final JFrame frame = new JFrame("Sign Up");
    private final JTextField userField = new JTextField();
    private final JPasswordField passField = new JPasswordField();
    private final JPasswordField confirmField = new JPasswordField();
    private final JButton signUpButton = new JButton("Sign Up");
    private final JButton backButton = new JButton("Back");
    private final ContactLink contactLink = new ContactLink();
    private final JLabel messageLabel = new JLabel("", SwingConstants.CENTER);
    private final UserStore store;
 
    public SignUpFrame(UserStore store) {
        this.store = store;
 
        JLabel userLabel = new JLabel("Username:");
        JLabel passLabel = new JLabel("Password:");
        JLabel confirmLabel = new JLabel("Confirm:");
 
        userLabel.setBounds(40, 50, 90, 25);
        passLabel.setBounds(40, 95, 90, 25);
        confirmLabel.setBounds(40, 140, 90, 25);
        userField.setBounds(140, 50, 190, 25);
        passField.setBounds(140, 95, 190, 25);
        confirmField.setBounds(140, 140, 190, 25);
        signUpButton.setBounds(140, 190, 90, 28);
        backButton.setBounds(240, 190, 90, 28);
        messageLabel.setBounds(30, 235, 320, 30);
        contactLink.setBounds(30, 280, 320, 25);
        messageLabel.setFont(new Font("SansSerif", Font.BOLD, 13));
 
        signUpButton.setFocusable(false);
        backButton.setFocusable(false);
        signUpButton.addActionListener(this);
        backButton.addActionListener(this);
        confirmField.addActionListener(this); // press Enter to sign up
 
        frame.add(userLabel);
        frame.add(passLabel);
        frame.add(confirmLabel);
        frame.add(userField);
        frame.add(passField);
        frame.add(confirmField);
        frame.add(signUpButton);
        frame.add(backButton);
        frame.add(messageLabel);
        frame.add(contactLink);
 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(380, 360);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
 
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == backButton) {
            frame.dispose();
            new LoginFrame(store);
            return;
        }
 
        String username = userField.getText().trim();
        String password = new String(passField.getPassword());
        String confirm = new String(confirmField.getPassword());
 
        if (username.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            showError("Please fill in all fields");
        } else if (username.length() < 3) {
            showError("Username must be at least 3 characters");
        } else if (username.contains(",") || username.contains(" ")) {
            showError("Username cannot contain spaces or commas");
        } else if (password.length() < 6) {
            showError("Password must be at least 6 characters");
        } else if (!password.equals(confirm)) {
            showError("Passwords do not match");
        } else if (store.userExists(username)) {
            showError("Username is already taken");
        } else if (!store.register(username, password)) {
            showError("Could not save the account");
        } else {
            JOptionPane.showMessageDialog(frame, "Account created. You can log in now.");
            frame.dispose();
            new LoginFrame(store);
        }
    }
 
    private void showError(String text) {
        messageLabel.setForeground(Color.RED);
        messageLabel.setText(text);
    }
}
